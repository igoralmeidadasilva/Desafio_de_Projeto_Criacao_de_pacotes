# image_processing

Description. 
The package package_name is used to:
	Processing:
		- Histogram Matching
		- Structural Similarity
		- Resize Image
	Utils:
		- Read Image
		- Save Image
		- Plot Image
		- Plot Result
		- Plot Histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing
```

## Author
Igor Almeida da Silva

## License
[MIT](https://choosealicense.com/licenses/mit/)